import { createSlice } from "@reduxjs/toolkit";

export const AuthCheckSlice = createSlice({
  name: "AuthCheck",
  initialState: {
    status: false,
    data:{}
  },
  reducers: {
    getAuth: (state, action) => {
      return {
        status: true,
        data:{...action.payload},
      };
    },
  },
});

export const AuthCheckAction = AuthCheckSlice.actions;
export default AuthCheckSlice;