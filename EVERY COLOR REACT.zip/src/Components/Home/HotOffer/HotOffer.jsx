import React, { useEffect, useState } from 'react';
import './HotOffer.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowRightLong } from '@fortawesome/free-solid-svg-icons';
import { Link, useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';

export default function HotOffer({uri,onSectionDataChange  }) {
  // console.log("data nad uri",  uri )
  const bannersStore = useSelector((store) => store.banners);
  const categoriesStore = useSelector((store) => store.categories);
  const { category } = useParams();


  const [sectionData, setSectionData] = useState({});

  const bannerItems = Array.isArray(bannersStore?.data) ? bannersStore.data : [];
  const categoryItems = Array.isArray(categoriesStore?.data) ? categoriesStore.data : [];

  useEffect(() => {
    const matchedCategory = categoryItems.find((c) => String(c.slug) === String(category));

    if (matchedCategory && matchedCategory.banner) {
      const data =({
        banner: matchedCategory.banner,
        name : matchedCategory.name || '',
        title: matchedCategory.title || '',
        sub_title: matchedCategory.sub_title || '',
        description: matchedCategory.description || '',
        meta_title: matchedCategory.meta_title,
        meta_description: matchedCategory.meta_description,
        meta_keyword:matchedCategory.meta_keyword,        
        button_text: 'Shop Now',
        slug: matchedCategory.slug || '',
      });
       setSectionData(data);
      onSectionDataChange?.(data);
      return;
    }

    if (bannersStore?.status !== false) {
      const hotBanners = bannerItems.filter((b) => String(b.type) === '1');
      if (hotBanners.length > 0) {
        const first = hotBanners[0];
        const data =({
          ...first,
          banner: first.banner || first.image || first.url || '',
        });
        setSectionData(data);
        onSectionDataChange?.(data); 
        return;
      }
    }

    setSectionData({});
  }, [bannersStore, categoryItems, category]);

  console.log( "section data ", sectionData)

  return (
    <section className="Hot_offers py-5">
      <div className="container">
        <div className="row justify-content-between align-items-center">
          <div className="col-lg-5  mb-lg-0 mb-4">
            <div className="Hot_offer-Content">
              {sectionData?.sub_title && <span>{sectionData.sub_title}</span>}
              {sectionData?.title && <h2>{sectionData.title}</h2>}
              {sectionData?.description && <p>{sectionData.description}</p>}
              <div className="button-dark mt-4">
                <Link to={`/product?category=${category}`}>
                  {sectionData?.button_text || 'Shop Now'}{' '}
                  <FontAwesomeIcon icon={faArrowRightLong} />
                </Link>
              </div>
            </div>
          </div>
          <div className="col-lg-5  mb-lg-0 mb-4">
            <div className="Hot_offer-image">
              {sectionData.banner ? (
                <img src={sectionData.banner} alt={sectionData.title || 'Hot offer'} />
              ) : (
                <div className="placeholder-image">No banner available</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
